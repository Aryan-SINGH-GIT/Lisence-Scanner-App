import React from 'react'

function Fetch() {
    const [data, setData] = React.useState(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);

    React.useEffect(() => {
        fetch('https://randomuser.me/api/')
            .then((res) => {
                if (!res.ok) throw new Error('Network response was not ok');
                return res.json();
            })
            .then((json) => {
                setData(json.results[0]);
                setLoading(false);
            })
            .catch((err) => {
                setError(err.message);
                setLoading(false);
                
            });
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    return (
        <div>
            <h2>Random User</h2>
            <img src={data.picture.large} alt="User" />
            <div>Name: {data.name.first} {data.name.last}</div>
            <div>Email: {data.email}</div>
            <div>Location: {data.location.city}, {data.location.country}</div>
        </div>
    );
}

export default Fetch
