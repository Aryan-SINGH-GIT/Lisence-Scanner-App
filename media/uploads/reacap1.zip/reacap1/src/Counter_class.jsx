import { Component } from "react";

export default class CounterClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
    };
  }

  sub = () => {
    this.setState({ count: this.state.count - 1 });
  };

  add = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <h1>Counter: {this.state.count}</h1>
        <button onClick={this.sub}>-</button>
        <button onClick={this.add}>+</button>
      </div>
    );
  }
}