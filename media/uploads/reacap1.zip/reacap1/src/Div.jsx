import React from 'react'

const Div = ({number}) => {
  return (
    <div>
      <h1>hello {number}</h1>
    </div>
  )
}

export default Div
