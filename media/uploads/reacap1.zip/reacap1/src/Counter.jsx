import React from 'react'
import { useState } from 'react'

function Counter() {
    const [num,setNum]= useState(0)
    const increase=()=>{
        setNum(num+1)
    }
    const decrease=()=>{
        setNum(num-1)
    }
  return (
    <div>
        <p>{num}</p>
      <button onClick={increase}>+</button>
      <button onClick={decrease}>-</button>
    </div>
  )
}

export default Counter
