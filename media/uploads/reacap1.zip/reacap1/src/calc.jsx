import React, { useState } from 'react'

function Calc() {
  const [num1, setNum1] = useState(0)
  const [num2, setNum2] = useState(0)
  const [res, setRes] = useState(0)

  const add = () => setRes(Number(num1) + Number(num2))
  const sub = () => setRes(Number(num1) - Number(num2))
  const mult = () => setRes(Number(num1) * Number(num2))

  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <input
        type="number"
        value={num1}
        onChange={e => setNum1(e.target.value)}
        placeholder="First number"
      />
      <input
        type="number"
        value={num2}
        onChange={e => setNum2(e.target.value)}
        placeholder="Second number"
        style={{ marginLeft: '1rem' }}
      />
      <div style={{ margin: '1rem 0' }}>
        <button onClick={add}>Add</button>
        <button onClick={sub} style={{ marginLeft: '0.5rem' }}>Subtract</button>
        <button onClick={mult} style={{ marginLeft: '0.5rem' }}>Multiply</button>
      </div>
      <h2>Result: {res}</h2>
    </div>
  )
}

export default Calc
