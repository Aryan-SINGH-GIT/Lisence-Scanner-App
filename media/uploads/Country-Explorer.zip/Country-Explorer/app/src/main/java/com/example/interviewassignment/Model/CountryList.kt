package com.example.interviewassignment.Model

class CountryList  : ArrayList<Country>() { }