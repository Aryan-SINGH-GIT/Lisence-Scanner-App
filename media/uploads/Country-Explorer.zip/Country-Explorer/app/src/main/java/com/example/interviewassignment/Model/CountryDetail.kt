package com.example.interviewassignment.Model

data class CountryDetail(
    val id: Int,
    val Name: String,
    val Flag: String,
    val region:String,
    val Population:Int,
    val Area:Int,
    val Currency:String,
    val Languages:String,

)
