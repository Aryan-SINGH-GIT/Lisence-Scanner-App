package com.example.interviewassignment.View

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.interviewassignment.Model.Country
import com.example.interviewassignment.R
import com.example.interviewassignment.Viewmodel.CountryViewHolder

class CountryAdapter (private val country_List:MutableList<Country>): RecyclerView.Adapter<CountryViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view: View =  LayoutInflater.from(parent.context).inflate(R.layout.country_item,parent,false)
        return CountryViewHolder(view)
    }
    override fun getItemCount() = country_List.size
    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.bind(country_List[position])
    }

    fun updateData(newList: List<Country>) {
        country_List.clear()
        country_List.addAll(newList)
        notifyDataSetChanged()
    }
}