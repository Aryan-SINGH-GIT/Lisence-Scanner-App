package com.example.interviewassignment.View

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.liveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.interviewassignment.Model.Country
import com.example.interviewassignment.Model.CountryList
import com.example.interviewassignment.R
import com.example.interviewassignment.Viewmodel.CountryService
import com.example.interviewassignment.Viewmodel.RetrofitInstance
import com.example.interviewassignment.databinding.ActivityMainBinding
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var chatAdapter: CountryAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        recyclerView = binding.myrecyclerview
        val item_list = mutableListOf<Country>()

        val retrofitService = RetrofitInstance.getRetrofitInstance().create(CountryService::class.java)
        val responseLiveData : LiveData<Response<CountryList>> = liveData {
            val response = retrofitService.getAlbums()
            emit(response)
        }
//        responseLiveData.observe(this, Observer{
//            val countryList = it.body()?.listIterator()
//            if (countryList!= null){
//                while (countryList.hasNext()){
//                    val countryItem = countryList.next()
//                    val countryName = countryItem.Name
//                    val countryRegion=countryItem.region
//                    val countrypopulation=countryItem.Population
//                    val countryImage=countryItem.Flag
//                    item_list.add(
//                        Country(
//                            countryName,
//                            countryImage,
//                            countryRegion,
//                            countrypopulation))
//
//                }
//            }
//        })

        responseLiveData.observe(this, Observer {
            val countryList = it.body()
            if (countryList != null) {
                chatAdapter.updateData(countryList)
            }

        })







        chatAdapter = CountryAdapter(item_list)
        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)

            adapter = this@MainActivity.chatAdapter
        }
    }
}
