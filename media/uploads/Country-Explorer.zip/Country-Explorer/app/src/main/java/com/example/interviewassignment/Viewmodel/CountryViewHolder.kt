package com.example.interviewassignment.Viewmodel

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.interviewassignment.Model.Country
import com.example.interviewassignment.Model.Flags
import com.example.interviewassignment.Model.Name
import com.example.interviewassignment.R

class CountryViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView) {
    private val countryName:TextView= itemView.findViewById(R.id.countryname)
    private val countryRegion:TextView = itemView.findViewById(R.id.countryregion)
    private val population:TextView = itemView.findViewById(R.id.population)
    private val Image: ImageView = itemView.findViewById(R.id.myimg)


    fun bind(countryItem: Country) {
        countryName.text = countryItem.name.common
        countryRegion.text = countryItem.region
        population.text = countryItem.population.toString()
        Glide.with(itemView.context)
            .load(countryItem.flags.png)
            .into(Image)
    }
}
