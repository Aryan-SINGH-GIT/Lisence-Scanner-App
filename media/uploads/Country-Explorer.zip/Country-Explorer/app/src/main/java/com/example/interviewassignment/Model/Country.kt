package com.example.interviewassignment.Model

import com.google.gson.annotations.SerializedName
//
//data class Country(
//
//@SerializedName("common")
//val Name: String,
//@SerializedName("png")
//val Flag: String,
//@SerializedName("region")
//val region:String,
//@SerializedName("population")
//val Population:Int
//
//)
data class Country(
    @SerializedName("name")
    val name: Name,

    @SerializedName("flags")
    val flags: Flags,

    @SerializedName("region")
    val region: String,

    @SerializedName("population")
    val population: Int
)

data class Name(
    @SerializedName("common")
    val common: String
)

data class Flags(
    @SerializedName("png")
    val png: String
)
