package com.example.interviewassignment.Viewmodel

import com.example.interviewassignment.Model.CountryList
import retrofit2.Response
import retrofit2.http.GET

interface CountryService {

    @GET("/v3.1/all")
    suspend fun  getAlbums(): Response<CountryList>

}
